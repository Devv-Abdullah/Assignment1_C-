﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ass1
{
    public partial class Form1 : Form
    {
        double x1, y1, x2, y2, r;
        bool a, b, c, d;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            a = double.TryParse(textBox1.Text, out x1);
            b = double.TryParse(textBox2.Text, out x2);
            c = double.TryParse(textBox3.Text, out y1);
            d = double.TryParse(textBox4.Text, out y2);

            if (a && b && c && d)
            {
                textBox5.Text += "Start Point is: (" + textBox1.Text + "," + textBox3.Text + ")" + "\r\n" + "End Point is: (" + textBox2.Text + "," + textBox4.Text + ")\r\n";

                tabPage3.BackgroundImage = Properties.Resources.cartesian;
            }
            else
                MessageBox.Show("Incorrect Format");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            a = double.TryParse(textBox1.Text, out x1);
            b = double.TryParse(textBox2.Text, out x2);
            c = double.TryParse(textBox3.Text, out y1);
            d = double.TryParse(textBox4.Text, out y2);

            if (a && b && c && d)
            {
                double midPointX = (x1 + x2) / 2;
                double midPointY = (y1 + y2) / 2;

                textBox5.Text += "The mid point is: (" + midPointX + " , " + midPointY + ")" + "\r\n";

                if(x2 - x1 == 0)
                {
                    textBox5.Text += "The line is vertical".ToString();
                    tabPage3.BackgroundImage = Properties.Resources.vertical;
                }
                else if(y2 -y1 == 0)
                {
                    textBox5.Text += "The line is Horizontal".ToString();
                }
                else
                {
                    tabPage3.BackgroundImage = Properties.Resources.cartesian;
                }
            }
            else
                MessageBox.Show("Incorrect Format");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            a = double.TryParse(textBox1.Text, out x1);
            b = double.TryParse(textBox2.Text, out x2);
            c = double.TryParse(textBox3.Text, out y1);
            d = double.TryParse(textBox4.Text, out y2);

            if (a && b && c && d)
            {

                double slope = (y2 - y1) / (x2 - x1);

                textBox5.Text += "The slope is:" + slope.ToString();

                if (slope > 0)
                {
                    textBox5.Text += "Right side of the line is higher than the left side".ToString();
                    tabPage3.BackgroundImage = Properties.Resources.positive4;
                }
                else if (slope < 0)
                {
                    textBox5.Text += "Line goes down and right".ToString();
                    tabPage3.BackgroundImage = Properties.Resources.negative;
                }
            }
            else
                MessageBox.Show("Incorrect Format");
        }


        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBox5.Font = new Font(textBox5.Font.FontFamily, textBox5.Font.Size, FontStyle.Bold ^ textBox5.Font.Style);
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            textBox5.Font = new Font(textBox5.Font.FontFamily, textBox5.Font.Size, FontStyle.Italic ^ textBox5.Font.Style);
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            a = double.TryParse(textBox1.Text, out x1);
            b = double.TryParse(textBox2.Text, out x2);
            c = double.TryParse(textBox3.Text, out y1);
            d = double.TryParse(textBox4.Text, out y2);

            if (a && b && c && d)
            {

                r = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
                textBox5.Text += "Distance between the two points:" + r.ToString();
                tabPage3.BackgroundImage = Properties.Resources.cartesian;
            }
            else
                MessageBox.Show("Incorrect Format");
        }
    }
}
